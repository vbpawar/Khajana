'use strict';

// Config the app
//
app.config({
  smoothScroll: true,
});




// Codes to be execute when all JS files are loaded and ready to use
//
app.ready(function() {



});
